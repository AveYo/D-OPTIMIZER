///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     _______             ______    ______    ________   __   ___  ___   __   ________   _______   ______
//    |   __  \           /      \  |   _  \  |        | |  | |   \/   | |  | |       /  |   ____| |   _  \
//    |  |  |  |         |  ,~~,  | |  |_)  | '~~|  |~~' |  | |  \  /  | |  | `~~~/  /   |  |__    |  |_)  |
//    |  |  |  | AVEYO`S |  |  |  | |   ___/     |  |    |  | |  |\/|  | |  |    /  /    |   __|   |      /
//    |  '~~'  |         |  '~~'  | |  |         |  |    |  | |  |  |  | |  |   /  /~~~, |  |____  |  |\  \
//    |_______/           \______/  |__|         |__|    |__| |__|  |__| |__|  /_______| |_______| |__| \__\
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Dota 2 7.00 annoyances quick client-side fix by AveYo
=======================================================================================================================
Step 1: Browse with a filemanager to
\steamapps\common\dota 2 beta\game\

Step 2: Delete directory (or just it's content):
dota_lv

Step 3: Unpack this zip file there

Step 4: Verify that this file exists
\steamapps\common\dota 2 beta\game\dota_lv\pak01_dir.vpk

Step 5: Add Dota 2 LAUNCH OPTIONS
-lv

Step 6: Profit

=======================================================================================================================
pak02_dir.vpk is optional - used to fix low-violence green blood particles

Might want to add to your autoexec.cfg:
violence_ablood 1; violence_agibs 1; violence_hblood 1; violence_hgibs 1;
