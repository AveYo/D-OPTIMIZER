///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     _______             ______    ______    ________   __   ___  ___   __   ________   _______   ______
//    |   __  \           /      \  |   _  \  |        | |  | |   \/   | |  | |       /  |   ____| |   _  \
//    |  |  |  |         |  ,~~,  | |  |_)  | '~~|  |~~' |  | |  \  /  | |  | `~~~/  /   |  |__    |  |_)  |
//    |  |  |  | AVEYO`S |  |  |  | |   ___/     |  |    |  | |  |\/|  | |  |    /  /    |   __|   |      /
//    |  '~~'  |         |  '~~'  | |  |         |  |    |  | |  |  |  | |  |   /  /~~~, |  |____  |  |\  \
//    |_______/           \______/  |__|         |__|    |__| |__|  |__| |__|  /_______| |_______| |__| \__\
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Dota 2 annoying ui sounds replacement mod v2 by AveYo
=======================================================================================================================
Step 1: Browse with a filemanager to
\steamapps\common\dota 2 beta\game\

Step 2: Delete directory (or just it's content):
dota_lv

Step 3: Unpack this zip file there

Step 4: Verify that this file exists
\steamapps\common\dota 2 beta\game\dota_lv\pak01_dir.vpk

Step 5: Add Dota 2 LAUNCH OPTIONS
-lv

Step 6: Profit

Might want to add to your autoexec.cfg:
violence_ablood 1; violence_agibs 1; violence_hblood 1; violence_hgibs 1;


What about localized support (non-english language)?
=======================================================================================================================
Unlike v1, this version is issue-free (friends feed works)

What is -lv? Any specific issues?
=======================================================================================================================
-lv stands for LowViolence (chinese censured mode)

Using -lv turns most blood green, even if you are not running the chinese client assets.
This mod circumvents it by patching the respective particle effects (only m_hLowViolenceDef line is removed)
Non-factor issue: console.log and possible other files will be saved in dota_lv instead of dota directory

-lv was first used in the ARCANA HOTKEYS mod exactly for these reasons. Hopefully, that mod will make a comeback soon..