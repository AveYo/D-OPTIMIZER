///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     _______             ______    ______    ________   __   ___  ___   __   ________   _______   ______
//    |   __  \           /      \  |   _  \  |        | |  | |   \/   | |  | |       /  |   ____| |   _  \
//    |  |  |  |         |  ,~~,  | |  |_)  | '~~|  |~~' |  | |  \  /  | |  | `~~~/  /   |  |__    |  |_)  |
//    |  |  |  | AVEYO`S |  |  |  | |   ___/     |  |    |  | |  |\/|  | |  |    /  /    |   __|   |      /
//    |  '~~'  |         |  '~~'  | |  |         |  |    |  | |  |  |  | |  |   /  /~~~, |  |____  |  |\  \
//    |_______/           \______/  |__|         |__|    |__| |__|  |__| |__|  /_______| |_______| |__| \__\
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Dota 2 annoying ui sounds replacement mod by AveYo
=======================================================================================================================
Step 1: Browse with a filemanager to
\steamapps\common\dota 2 beta\game\

Step 2: Unpack this zip file there

Step 3: Verify that this file exists
\steamapps\common\dota 2 beta\game\dota_ui\pak01_dir.vpk

Step 4: Add Dota 2 LAUNCH OPTIONS
-language ui +cl_language english +english 1

Step 5: Profit


What about localized support (non-english language)?
=======================================================================================================================
Rename directory
\steamapps\common\dota 2 beta\game\dota_ui
to
\steamapps\common\dota 2 beta\game\dota_yourlanguagename
Example for German:
\steamapps\common\dota 2 beta\game\dota_german

Replace all Step 4 Dota 2 LAUNCH OPTIONS with
-language yourlanguagename
Example for German:
-language german


Does not work?
=======================================================================================================================
Not supported for schinese, russian, koreana as it will override localized resources
Knowing how to merge the sound files to your respective pak_01.dir files is expected :D
