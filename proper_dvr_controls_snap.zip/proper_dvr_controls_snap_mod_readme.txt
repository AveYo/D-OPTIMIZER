///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     _______             ______    ______    ________   __   ___  ___   __   ________   _______   ______
//    |   __  \           /      \  |   _  \  |        | |  | |   \/   | |  | |       /  |   ____| |   _  \
//    |  |  |  |         |  ,~~,  | |  |_)  | '~~|  |~~' |  | |  \  /  | |  | `~~~/  /   |  |__    |  |_)  |
//    |  |  |  | AVEYO`S |  |  |  | |   ___/     |  |    |  | |  |\/|  | |  |    /  /    |   __|   |      /
//    |  '~~'  |         |  '~~'  | |  |         |  |    |  | |  |  |  | |  |   /  /~~~, |  |____  |  |\  \
//    |_______/           \______/  |__|         |__|    |__| |__|  |__| |__|  /_______| |_______| |__| \__\
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

How to install:  
=======================================================================================================================  
Step 1: Browse with a filemanager to  
\steamapps\common\dota 2 beta\game\

Step 2: Delete directory (or just it's content):  
dota_lv  

Step 3: Unpack this zip file there

Step 4: Verify that these files exists  
\steamapps\common\dota 2 beta\game\dota_lv\pak01_dir.vpk  

Step 5: Add Dota 2 LAUNCH OPTIONS  
-lv

Step 6: Profit  

Notes:  
=======================================================================================================================  
this is a quick proof of concept so it does not include the lowviolence particles fix (blood will be alien green)
you could use instead LAUNCH OPTIONS: -language lv   