 Dota 2 Ding-Ding_Mofo Stinger

Auto one-click install mod for Windows: just run the included batch file

Manual install mod (unzip to \steamapps\common\) - Files:
\Steam\steamapps\common\dota 2 beta\game\avemod01\pak01_dir.vpk
\Steam\steamapps\common\dota 2 beta\game\dota\gameinfo.gi
\Steam\steamapps\common\dota 2 beta\game\dota\old_gameinfo.gi