///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     _______             ______    ______    ________   __   ___  ___   __   ________   _______   ______
//    |   __  \           /      \  |   _  \  |        | |  | |   \/   | |  | |       /  |   ____| |   _  \
//    |  |  |  |         |  ,~~,  | |  |_)  | '~~|  |~~' |  | |  \  /  | |  | `~~~/  /   |  |__    |  |_)  |
//    |  |  |  | AVEYO`S |  |  |  | |   ___/     |  |    |  | |  |\/|  | |  |    /  /    |   __|   |      /
//    |  '~~'  |         |  '~~'  | |  |         |  |    |  | |  |  |  | |  |   /  /~~~, |  |____  |  |\  \
//    |_______/           \______/  |__|         |__|    |__| |__|  |__| |__|  /_______| |_______| |__| \__\ v3.1
//
//    ARCANA HOTKEYS II : QuickCast Enhancements, Multiple Chatwheels, Camera Actions, Panorama Keys - All in GUI
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

HOW TO INSTALL:
If you are on Windows, using the batch file is the recommended method

For manual install, just unpack and copy this zip file to your steamapps folder where Dota 2 is installed
then add Dota 2 Launch Option: -LV

Probably works on Linux and Mac too