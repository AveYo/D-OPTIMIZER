// ===================================================
// Total.js - framework for Node.js platform
// https://www.totaljs.com
// ===================================================
const options = {};
options.data = true; // set to false to hide data in the console
// options.ip = '127.0.0.1';
// options.port = parseInt(process.argv[2]);
// options.config = { name: 'Total.js' };
// options.sleep = 3000;

require('total.js').http('release', options);
// require('total.js').cluster.http(5, 'release', options);

//==================================================================================================================================
NOSQL('users').upsert({id: '000', steam_id: '000', data : {}, datecreated:F.datetime}, true).where('steam_id', '000');

//==================================================================================================================================
NEWSCHEMA('User').make(function(schema) {
  schema.define('id', 'UID');
  schema.define('api_key', 'String', true);
  schema.define('steam_id', 'String', true);
  schema.define('data', 'JSON', true);
//----------------------------------------------------------------------------------------------------------------------------------
  schema.setQuery(function(error, options, callback, controller) {
    // Validation
    var check={nr: error.count==0, key: options.api_key==F.config.api_key};
    if (options.data) console.log('schema.setQuery', options.steam_id, check);
    if (!check.nr || !check.key) {
      callback({data:{success: false, details: check}, errors: {error_code: 404, message:'Q'}});
      return;
    }
    // Reads the user
    NOSQL('users').find().search('steam_id', options.steam_id).callback(callback);
  });
//----------------------------------------------------------------------------------------------------------------------------------
  schema.setGet(function(error, model, options, callback, controller) {
    // Validation
    var check={nr: error.count==0, key: options.api_key==F.config.api_key, id: (!!options.steam_id)==true};
    if (!!options.data) console.log('schema.setGet', options.steam_id, check);
    if (!check.nr || !check.key || !check.id) {
      callback({data:{success: false, details: check}, errors: {error_code: 404, message:'G'}});
      return;
    }
    // Reads the user
    NOSQL('users').one().where('steam_id', options.steam_id).callback(function(err, response){
      var output={data: response};
      try{ console.log(JSON.stringify(output.data.data, null, 4)) }catch(e){};
      if (err || !!response==false) output.errors={error_code: 404, message:'G', err: err || ''};
      callback(output);
    });
  });
//----------------------------------------------------------------------------------------------------------------------------------
  schema.setSave(function(error, model, options, callback, controller) {
    // Validation
    var check={nr: error.count==0, key: options.api_key==F.config.api_key, id: (!!options.steam_id)==true};
    if (options.data) console.log('schema.setSave', options.steam_id, check);
    if (!check.nr || !check.id || !check.key) {
      callback({data:{success: false, details: check}, errors: {error_code: 404, message:'S'}});
      return;
    }
    // Removes hidden properties of the SchemaBuilder
    var data = model.$clean();
    // data.data is expected as json - attempt to parse it
    try{ data.data = JSON.parse(data.data) }catch(e){};
    // Checks if the user exists
    NOSQL('users').one().where('steam_id', options.steam_id).fields('id').callback(function(err, response) {
      var id = (!!response) ? response.id : '';
      if (options.data) console.log('[ID]=',id);
      if (!id) {
        data.id = UID();
        data.datecreated = F.datetime;
        NOSQL('users').insert(data).callback(SUCCESS(callback));
        return;
      }
      data.dateupdated = F.datetime;
      // We don't need to modify id
      data.id = undefined;
      NOSQL('users').modify(data).where('id', id).callback(SUCCESS(callback));
    });
  });
//----------------------------------------------------------------------------------------------------------------------------------
});
//==================================================================================================================================
//exports.install = function() {
  // Sets cors for this API
  F.cors('/*', ['get', 'post'], true);
  // Creates routes
  F.route('/query',  nosql_query,          ['*User']);  //   http://localhost/query?api_key=ReIncarnation_Release&steam_id=
  F.route('/',       nosql_read,           ['*User']);  //   http://localhost/?api_key=ReIncarnation_Release&steam_id=12345
  F.route('/',       nosql_save,   ['post', '*User']);  //   http://localhost/?api_key=ReIncarnation_Release&steam_id=10000&data={}
//};
//==================================================================================================================================
function nosql_query() {
  var self = this;
  console.log('nosql_query', self.query.steam_id);
  self.$query(self.query, self.callback());
}
function nosql_read() {
  var self = this;
  console.log('nosql_read',self.query.steam_id);
  self.$get(self.query, self.callback());
}
function nosql_save() {
  var self = this;
  console.log('nosql_save', self.body.steam_id);
  self.$save(self.body, self.callback());
}
//==================================================================================================================================
F.on('request', function(req, res){
    console.log(`[${req.method}] ${req.url}`); 
});

//==================================================================================================================================
global.SUCCESS = function(success, value) {
    if (typeof(success) === 'function') {
      return function(err, value) {success(err, SUCCESS(err, value))};
    }
    var err;
    if (success instanceof Error) { 
        err = success.toString(); success = false;
    } else if (success instanceof ErrorBuilder) {
        if (success.hasError()) {err = success.output(); success = false;} else {success = true;}
    } else if (success == null) success = true;
    if (err) return {"errors":{"error_code":404,"message":"?"}};
    else if (success) return {"data":{"success":"true"}};
    else return { error: 'Repeat your operation.' };
};