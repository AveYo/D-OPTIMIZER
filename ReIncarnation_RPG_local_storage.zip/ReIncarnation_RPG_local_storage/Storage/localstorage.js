// ==========================================================
// Local Storage by AveYo v2 (CC) 2017 
// for Reincarnation RPG Dota custom game by Dreoh and JoBoDo
// ========================================================== 
const API_KEY  = 'ReIncarnation_Release';

var express    = require('express');
var bodyParser = require('body-parser');

var app        = express();
app.set('ip', process.argv[2] || '0.0.0.0');
app.set('port', parseInt(process.argv[3]) || 80);

var http       = require('http').Server(app);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var DB         = require('total.js').nosql;
NOSQL('users').upsert({api_key: API_KEY, steam_id: '000', data: {date: F.datetime}}, true).where('steam_id', '000'); // not required
//----------------------------------------------------------------------------------------------------------------------------------  

app.post('/',function(req,res){
  var data={};
  data.api_key = req.body.api_key;
  data.steam_id = req.body.steam_id;
  data.data = req.body.data;
  // Validation
  if (data.api_key != API_KEY || !!data.steam_id==false) {
    res.send( {"errors":{"error_code":500,"message":"post"}} );
    console.log('#err 500 post');
    return;
  } 
  NOSQL('users').update(data, true).where('steam_id', req.body.steam_id).callback(function(err, results) {
    if(err){
      res.send( {"errors":{"error_code":404,"message":"post"}} );
      console.log('#err 404 post');
    }else{
      res.send( {"data":{"success":"true"}} );
      try{ data.data = JSON.parse(data.data); }catch(e){}
      try{ console.log('#update\n',JSON.stringify(data, null, 4), '\n#updated', req.body.steam_id); }catch(e){}
    }
  });
});
//---------------------------------------------------------------------------------------------------------------------------------- 

app.get('/',function(req,res){
  var data={}
  data.api_key = req.query.api_key;
  data.steam_id = req.query.steam_id;
  // Validation
  if (data.api_key != API_KEY || !!data.steam_id==false) {
    res.send( {"errors":{"error_code":500,"message":"get"}} );
    console.log('#err 500 get');
    return;
  } 
  NOSQL('users').one().where('steam_id', req.query.steam_id).callback(function(err, results) {
    if(err || !!results == false){
      res.send( {"errors":{"error_code":404,"message":"get"}} );
      console.log('#err 404 get'); 
    }else{
      var data = {data: results};
      try{ data.data.data = JSON.parse(data.data.data); }catch(e){}
      res.send(data);
      try{ console.log('#get\n', JSON.stringify(data, null, 4), '\n#got', req.query.steam_id); }catch(e){}
    }
  });
});
//---------------------------------------------------------------------------------------------------------------------------------- 

http.listen(app.get('port'),function(){
 console.log('Local Storage Server for ReIncarnation RPG started on ' + app.get('ip') +':'+ app.get('port'));
});
