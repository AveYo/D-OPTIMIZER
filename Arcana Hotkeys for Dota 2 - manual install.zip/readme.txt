//  AVEYO's D-OPTIMIZER V3 - 2016 (cc)
//  Introducing ARCANA HOTKEYS : Unified CastControl, Multiple Chatwheel Presets and Builder, Camera Actions, Panorama Keys

HOW TO INSTALL:
If you are on Windows, using the batch file is the recommended method

For manual install, just unpack and copy this zip file to your steamapps folder where Dota 2 is installed
then add Dota 2 Launch Option: -LV

Probably works on Linux and Mac too