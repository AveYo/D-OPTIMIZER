
  To install this Unreal Tournament Female Announcer Mod for Dota 2:
  - open Steam > Library > Dota2 > right-click Properties > Installed files > Browse..
  - copy game/ subfolder over there, overwriting existing files:
  dota_mods/pak01_dir.vpk
  dota/gameinfo_branchspecific.gi
  - or skip gameinfo_branchspecific.gi and use instead launch option: -language mods

  To explore game/dota_mods/pak01_dir.vpk and compiled *_c content:
  - use VRF tool by SteamDatabase: github.com/SteamDatabase/ValveResourceFormat/

  This replaces 14 sounds of the default killing spree announcer as well as CM, DW & Lina ones